import { Component } from '@angular/core';

@Component({
  selector: 'app-weather-information',
  imports: [],
  templateUrl: './weather-information.component.html',
  styleUrl: './weather-information.component.css'
})
export class WeatherInformationComponent {

}
