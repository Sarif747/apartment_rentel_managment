import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-tenant-management',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  templateUrl: './tenant-management.component.html',
  styleUrls: ['./tenant-management.component.css']
})
export class TenantManagementComponent implements OnInit {
  selectedOption: string = 'viewTenants';
  tenantForm: FormGroup;
  updateForm: FormGroup;
  tenants: any[] = [];
  filteredTenants: any[] = [];
  selectedTenant: any;
  searchQuery: string = '';
  successMessage: string = '';
  errorMessage: string = '';

  constructor(private fb: FormBuilder) {
    this.tenantForm = this.fb.group({
      tenantId: ['', Validators.required],
      fullName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', Validators.required],
      apartmentNumber: ['', Validators.required],
      leaseStartDate: ['', Validators.required],
      leaseEndDate: ['', Validators.required],
    });

    this.updateForm = this.fb.group({
      tenantId: ['', Validators.required],
      fullName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', Validators.required],
      apartmentNumber: ['', Validators.required],
      leaseStartDate: ['', Validators.required],
      leaseEndDate: ['', Validators.required],
    });
  }

  ngOnInit() {
    this.tenants = [];
    this.filteredTenants = [...this.tenants];
  }

  selectOption(option: string) {
    this.selectedOption = option;
    this.successMessage = '';
    this.errorMessage = '';
  }

  filterTenants() {
    const query = this.searchQuery.toLowerCase();
    const foundTenant = this.tenants.find(tenant =>
      tenant.tenantId.toLowerCase().includes(query) ||
      tenant.fullName.toLowerCase().includes(query)
    );
    if (foundTenant) {
      this.selectedTenant = foundTenant;
      this.updateForm.patchValue({
        tenantId: foundTenant.tenantId,
        fullName: foundTenant.fullName,
        email: foundTenant.email,
        phone: foundTenant.phone,
        apartmentNumber: foundTenant.apartmentNumber,
        leaseStartDate: foundTenant.leaseStartDate,
        leaseEndDate: foundTenant.leaseEndDate,
      });
      this.errorMessage = '';
    } else {
      this.selectedTenant = null;
      this.errorMessage = 'No tenants found for the search criteria.';
    }
  }

  onSubmit() {
    this.successMessage = '';
    this.errorMessage = '';

    if (this.tenantForm.valid) {
      this.tenants.push(this.tenantForm.value);
      this.filteredTenants.push(this.tenantForm.value);
      this.tenantForm.reset();
      this.successMessage = 'Tenant created successfully!';
      setTimeout(() => { this.successMessage = ''; }, 3000);
    } else {
      this.errorMessage = 'Please fill in all required fields.';
      setTimeout(() => { this.errorMessage = ''; }, 3000);
    }
  }

  onUpdate() {
    this.successMessage = '';
    this.errorMessage = '';

    if (this.updateForm.valid && this.selectedTenant) {
      const updatedTenant = this.updateForm.value;
      const index = this.tenants.findIndex(tenant => tenant.tenantId === this.selectedTenant.tenantId);
      if (index !== -1) {
        this.tenants[index] = { ...this.selectedTenant, ...updatedTenant };
        this.filteredTenants[index] = { ...this.selectedTenant, ...updatedTenant };
        this.selectedTenant = null;
        this.successMessage = 'Tenant updated successfully!';
        setTimeout(() => { this.successMessage = ''; }, 3000);
      }
    } else {
      this.errorMessage = 'Please fill in all required fields.';
      setTimeout(() => { this.errorMessage = ''; }, 3000);
    }
  }

  deleteTenant(tenant: any) {
    this.successMessage = '';
    this.errorMessage = '';

    const index = this.tenants.findIndex(t => t.tenantId === tenant.tenantId);
    if (index !== -1) {
      this.tenants.splice(index, 1);
      this.filteredTenants = this.filteredTenants.filter(t => t.tenantId !== tenant.tenantId);
      this.successMessage = 'Tenant deleted successfully!';
      setTimeout(() => { this.successMessage = ''; }, 3000);
    } else {
      this.errorMessage = 'Error: Tenant not found.';
      setTimeout(() => { this.errorMessage = ''; }, 3000);
    }
  }

  selectTenantToUpdate(tenant: any) {
    this.selectedTenant = tenant;
    this.updateForm.patchValue({
      tenantId: tenant.tenantId,
      fullName: tenant.fullName,
      email: tenant.email,
      phone: tenant.phone,
      apartmentNumber: tenant.apartmentNumber,
      leaseStartDate: tenant.leaseStartDate,
      leaseEndDate: tenant.leaseEndDate,
    });
  }

  onClearSearch() {
    this.searchQuery = '';
    this.selectedTenant = null;
    this.updateForm.reset();
  }
}