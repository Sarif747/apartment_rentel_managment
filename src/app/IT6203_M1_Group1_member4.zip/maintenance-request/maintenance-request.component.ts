import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

// Define the MaintenanceRequest interface
interface MaintenanceRequest {
  id: number;
  requestNumber: string;
  apartmentNumber: string;
  tenantName: string;
  issueDescription: string;
  requestDate: string;
  priority: 'Low' | 'Medium' | 'High';
  status: 'Pending' | 'In Progress' | 'Completed';
}

@Component({
  selector: 'app-maintenance-request',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './maintenance-request.component.html',
  styleUrls: ['./maintenance-request.component.css']
})
export class MaintenanceRequestComponent implements OnInit {
  // View state
  activeView: 'create' | 'view' | 'update' | 'delete' = 'view';

  // Maintenance requests data
  maintenanceRequests: MaintenanceRequest[] = [];

  // Form models
  newRequest: Partial<MaintenanceRequest> = this.initializeNewRequest();
  selectedRequest: MaintenanceRequest | null = null;
  updateRequestId: string = '';
  deleteRequestId: string = '';

  constructor() { }

  ngOnInit(): void {
    // Load sample data for demonstration
    this.loadSampleRequests();
  }

  // Method to switch between views
  setActiveView(view: 'create' | 'view' | 'update' | 'delete'): void {
    this.activeView = view;
    this.selectedRequest = null; // Reset selected request when switching views
    this.updateRequestId = '';
    this.deleteRequestId = '';

    // Reset the new request form when switching to the create view
    if (view === 'create') {
      this.newRequest = this.initializeNewRequest();
    }
  }

  // Initialize a new request
  initializeNewRequest(): Partial<MaintenanceRequest> {
    return {
      requestNumber: '',
      apartmentNumber: '',
      tenantName: '',
      issueDescription: '',
      requestDate: '',
      priority: 'Low',
      status: 'Pending'
    };
  }

  // Create a new maintenance request
  createMaintenanceRequest(): void {
    if (!this.validateRequestForm(this.newRequest)) {
      alert('Please fill in all required fields');
      return;
    }

    const request: MaintenanceRequest = {
      ...this.newRequest as MaintenanceRequest,
      id: this.generateId()
    };

    this.maintenanceRequests.push(request);
    alert('Maintenance request created successfully!');
    this.newRequest = this.initializeNewRequest();
    this.setActiveView('view');
  }

  // Update an existing maintenance request
  updateMaintenanceRequest(): void {
    if (!this.selectedRequest) {
      return;
    }

    if (!this.validateRequestForm(this.selectedRequest)) {
      alert('Please fill in all required fields');
      return;
    }

    const index = this.maintenanceRequests.findIndex(request => request.id === this.selectedRequest!.id);
    if (index !== -1) {
      this.maintenanceRequests[index] = { ...this.selectedRequest };
      alert('Maintenance request updated successfully!');
      this.selectedRequest = null;
      this.updateRequestId = '';
      this.setActiveView('view');
    }
  }

  // Delete a maintenance request
  deleteMaintenanceRequest(): void {
    if (!this.selectedRequest) {
      return;
    }

    this.maintenanceRequests = this.maintenanceRequests.filter(request => request.id !== this.selectedRequest!.id);
    alert('Maintenance request deleted successfully!');
    this.selectedRequest = null;
    this.deleteRequestId = '';
    this.setActiveView('view');
  }

  // Validate the maintenance request form
  private validateRequestForm(request: Partial<MaintenanceRequest>): boolean {
    return !!(
      request.requestNumber &&
      request.apartmentNumber &&
      request.tenantName &&
      request.issueDescription &&
      request.requestDate &&
      request.priority &&
      request.status
    );
  }

  // Generate a unique ID for new requests
  private generateId(): number {
    return this.maintenanceRequests.length > 0
      ? Math.max(...this.maintenanceRequests.map(request => request.id)) + 1
      : 1;
  }

  // Load sample data for demonstration
  private loadSampleRequests(): void {
    this.maintenanceRequests = [
      {
        id: 1,
        requestNumber: 'R-1001',
        apartmentNumber: 'A101',
        tenantName: 'John Smith',
        issueDescription: 'Leaky faucet in the kitchen',
        requestDate: '2024-01-15',
        priority: 'Medium',
        status: 'Pending'
      },
      {
        id: 2,
        requestNumber: 'R-1002',
        apartmentNumber: 'B205',
        tenantName: 'Emily Johnson',
        issueDescription: 'Broken heater in the living room',
        requestDate: '2024-02-01',
        priority: 'High',
        status: 'In Progress'
      },
      {
        id: 3,
        requestNumber: 'R-1003',
        apartmentNumber: 'C310',
        tenantName: 'Michael Williams',
        issueDescription: 'Clogged bathroom drain',
        requestDate: '2024-02-10',
        priority: 'Low',
        status: 'Completed'
      }
    ];
  }

  // Handle selection for update
  onUpdateRequestSelect(): void {
    if (this.updateRequestId) {
      const id = parseInt(this.updateRequestId, 10);
      const request = this.maintenanceRequests.find(r => r.id === id);
      if (request) {
        this.selectedRequest = { ...request };
      }
    } else {
      this.selectedRequest = null;
    }
  }

  // Handle selection for delete
  onDeleteRequestSelect(): void {
    if (this.deleteRequestId) {
      const id = parseInt(this.deleteRequestId, 10);
      const request = this.maintenanceRequests.find(r => r.id === id);
      if (request) {
        this.selectedRequest = { ...request };
      }
    } else {
      this.selectedRequest = null;
    }
  }

  // Select a request for update
  selectRequestForUpdate(request: MaintenanceRequest): void {
    this.selectedRequest = { ...request };
    this.updateRequestId = request.id.toString();
    this.setActiveView('update');
  }

  // Select a request for delete
  selectRequestForDelete(request: MaintenanceRequest): void {
    this.selectedRequest = { ...request };
    this.deleteRequestId = request.id.toString();
    this.setActiveView('delete');
  }

  // Cancel update
  cancelUpdate(): void {
    this.selectedRequest = null;
    this.updateRequestId = '';
  }

  // Cancel delete
  cancelDelete(): void {
    this.selectedRequest = null;
    this.deleteRequestId = '';
  }
}