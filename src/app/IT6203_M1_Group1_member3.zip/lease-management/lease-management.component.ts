import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';


interface Lease {
  id: number;
  leaseNumber: string;
  apartmentNumber: string;
  tenantName: string;
  startDate: string;
  endDate: string;
  monthlyRent: number;
  securityDeposit: number;
  isPetAllowed: boolean;
  isSmokingAllowed: boolean;
  includesUtilities: boolean;
  specialTerms: string;
}

@Component({
  selector: 'app-lease-management',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './lease-management.component.html',
  styleUrls: ['./lease-management.component.css']
})
export class LeaseManagementComponent implements OnInit {

  activeView: 'create' | 'view' | 'update' | 'delete' = 'view';
  

  leases: Lease[] = [];
  

  newLease: Partial<Lease> = this.initializeNewLease();
  selectedLease: Lease | null = null;
  updateLeaseId: string = '';
  deleteLeaseId: string = '';
  
  constructor() { }

  ngOnInit(): void {
   
    this.loadSampleLeases();
  }

  setActiveView(view: 'create' | 'view' | 'update' | 'delete'): void {
    this.activeView = view;
    this.selectedLease = null;
    this.updateLeaseId = '';
    this.deleteLeaseId = '';
    
    if (view === 'create') {
      this.newLease = this.initializeNewLease();
    }
  }

 createLease(): void {
  console.log('New Lease:', this.newLease);


  if (!this.validateLeaseForm(this.newLease)) {
    alert('Please fill in all required fields');
    return;
  }


  const lease: Lease = {
    ...this.newLease as Lease,
    id: this.generateId()
  };


  this.leases.push(lease);


  alert('Lease created successfully!');
  this.newLease = this.initializeNewLease();


  this.setActiveView('view');
}


  updateLease(): void {
    if (!this.selectedLease) {
      return;
    }

    if (!this.validateLeaseForm(this.selectedLease)) {
      alert('Please fill in all required fields');
      return;
    }


    const index = this.leases.findIndex(lease => lease.id === this.selectedLease!.id);
    
    if (index !== -1) {
  
      this.leases[index] = { ...this.selectedLease };
      

      alert('Lease updated successfully!');
      

      this.selectedLease = null;
      this.updateLeaseId = '';
      this.setActiveView('view');
    }
  }

  deleteLease(): void {
    if (!this.selectedLease) {
      return;
    }

    
    this.leases = this.leases.filter(lease => lease.id !== this.selectedLease!.id);
    

    alert('Lease deleted successfully!');

    this.selectedLease = null;
    this.deleteLeaseId = '';
    this.setActiveView('view');
  }


  onUpdateLeaseSelect(): void {
    if (this.updateLeaseId) {
      const id = parseInt(this.updateLeaseId, 10);
      const lease = this.leases.find(l => l.id === id);
      if (lease) {

        this.selectedLease = { ...lease };
      }
    } else {
      this.selectedLease = null;
    }
  }

  onDeleteLeaseSelect(): void {
    if (this.deleteLeaseId) {
      const id = parseInt(this.deleteLeaseId, 10);
      const lease = this.leases.find(l => l.id === id);
      if (lease) {

        this.selectedLease = { ...lease };
      }
    } else {
      this.selectedLease = null;
    }
  }

  selectLeaseForUpdate(lease: Lease): void {
    this.selectedLease = { ...lease };
    this.updateLeaseId = lease.id.toString();
    this.setActiveView('update');
  }

  selectLeaseForDelete(lease: Lease): void {
    this.selectedLease = { ...lease };
    this.deleteLeaseId = lease.id.toString();
    this.setActiveView('delete');
  }

  cancelUpdate(): void {
    this.selectedLease = null;
    this.updateLeaseId = '';
  }

  cancelDelete(): void {
    this.selectedLease = null;
    this.deleteLeaseId = '';
  }

  isLeaseActive(lease: Lease): boolean {
    const today = new Date();
    const endDate = new Date(lease.endDate);
    return endDate >= today;
  }

  private initializeNewLease(): Partial<Lease> {
    return {
      leaseNumber: '',
      apartmentNumber: '',
      tenantName: '',
      startDate: '',
      endDate: '',
      monthlyRent: 0,
      securityDeposit: 0,
      isPetAllowed: false,
      isSmokingAllowed: false,
      includesUtilities: false,
      specialTerms: ''
    };
  }

 private validateLeaseForm(lease: Partial<Lease>): boolean {

  return !!(
    lease.leaseNumber &&
    lease.apartmentNumber &&
    lease.tenantName &&
    lease.startDate &&
    lease.endDate &&
    lease.monthlyRent
  );
}


  private generateId(): number {
   
    return this.leases.length > 0
      ? Math.max(...this.leases.map(lease => lease.id)) + 1
      : 1;
  }

  private loadSampleLeases(): void {

    this.leases = [
      {
        id: 1,
        leaseNumber: 'L-1001',
        apartmentNumber: 'A101',
        tenantName: 'John Smith',
        startDate: '2024-01-01',
        endDate: '2025-01-01',
        monthlyRent: 1200,
        securityDeposit: 1200,
        isPetAllowed: true,
        isSmokingAllowed: false,
        includesUtilities: true,
        specialTerms: 'Tenant responsible for lawn maintenance.'
      },
      {
        id: 2,
        leaseNumber: 'L-1002',
        apartmentNumber: 'B205',
        tenantName: 'Emily Johnson',
        startDate: '2024-02-15',
        endDate: '2025-02-15',
        monthlyRent: 1500,
        securityDeposit: 1500,
        isPetAllowed: false,
        isSmokingAllowed: false,
        includesUtilities: false,
        specialTerms: 'No overnight guests for more than 3 consecutive nights.'
      },
      {
        id: 3,
        leaseNumber: 'L-1003',
        apartmentNumber: 'C310',
        tenantName: 'Michael Williams',
        startDate: '2023-11-01',
        endDate: '2024-11-01',
        monthlyRent: 1350,
        securityDeposit: 1350,
        isPetAllowed: true,
        isSmokingAllowed: false,
        includesUtilities: true,
        specialTerms: 'Pet deposit of $300 required.'
      }
    ];
  }
}