import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-apartment-management',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  templateUrl: './apartment-management.component.html',
  styleUrls: ['./apartment-management.component.css']
})
export class ApartmentManagementComponent implements OnInit {
  selectedOption: string = 'viewApartments';
  apartmentForm: FormGroup;
  updateForm: FormGroup;
  amenities: string[] = [];
  apartments: any[] = [];
  filteredApartments: any[] = [];
  selectedApartment: any;
  searchQuery: string = '';
  successMessage: string = '';
  errorMessage: string = '';

  constructor(private fb: FormBuilder) {
    this.apartmentForm = this.fb.group({
      apartmentNumber: ['', Validators.required],
      address: ['', Validators.required],
      buildingNumber: ['', Validators.required],
      bedrooms: ['', Validators.required],
      bathrooms: ['', Validators.required],
      price: ['', Validators.required],
      squareFootage: ['', Validators.required],
      amenities: this.fb.group({
        pool: [false],
        gym: [false],
        parking: [false],
      }),
    });

    this.updateForm = this.fb.group({
      apartmentNumber: ['', Validators.required],
      address: ['', Validators.required],
      buildingNumber: ['', Validators.required],
      bedrooms: ['', Validators.required],
      bathrooms: ['', Validators.required],
      price: ['', Validators.required],
      squareFootage: ['', Validators.required],
      amenities: this.fb.group({
        pool: [false],
        gym: [false],
        parking: [false],
      }),
    });
  }

  ngOnInit() {
    this.apartments = [];
    this.filteredApartments = [...this.apartments];
  }

  selectOption(option: string) {
    this.selectedOption = option;
    this.successMessage = '';
    this.errorMessage = '';
  }

  filterApartments() {

    const query = this.searchQuery.toLowerCase();
    const foundApartment = this.apartments.find(apartment =>
      apartment.apartmentNumber.toLowerCase().includes(query)
    );
    if (foundApartment) {
      this.selectedApartment = foundApartment;
      this.updateForm.patchValue({
        apartmentNumber: foundApartment.apartmentNumber,
        address: foundApartment.address,
        buildingNumber: foundApartment.buildingNumber,
        bedrooms: foundApartment.bedrooms,
        bathrooms: foundApartment.bathrooms,
        price: foundApartment.price,
        squareFootage: foundApartment.squareFootage,
        amenities: {
          pool: foundApartment.amenities?.includes('Pool') || false,
          gym: foundApartment.amenities?.includes('Gym') || false,
          parking: foundApartment.amenities?.includes('Parking') || false
        }
      });
      this.errorMessage = '';
    } else {
      this.selectedApartment = null;
       this.errorMessage = 'No apartments found for the search criteria.';
    }
  }
  
  
  onSubmit() {
    this.successMessage = '';
    this.errorMessage = '';

    if (this.apartmentForm.valid) {
      this.apartments.push(this.apartmentForm.value);
      this.filteredApartments.push(this.apartmentForm.value);
      this.apartmentForm.reset();
      // this.clearAmenities();

      this.successMessage = 'Apartment created successfully!';
      setTimeout(() => { this.successMessage = ''; }, 3000);
    } else {
      this.errorMessage = 'Please fill in all required fields.';
      setTimeout(() => { this.errorMessage = ''; }, 3000);
    }
  }

  onUpdate() {
    this.successMessage = '';
    this.errorMessage = '';

    if (this.updateForm.valid && this.selectedApartment) {
      const updatedApartment = this.updateForm.value;
      const index = this.apartments.findIndex(apartment => apartment.apartmentNumber === this.selectedApartment.apartmentNumber);
      if (index !== -1) {
        this.apartments[index] = { ...this.selectedApartment, ...updatedApartment };
        this.filteredApartments[index] = { ...this.selectedApartment, ...updatedApartment };
        this.selectedApartment = null;
        // this.updateForm.reset();
        // this.clearAmenities();

        this.successMessage = 'Apartment updated successfully!';
        setTimeout(() => { this.successMessage = ''; }, 3000);
      }
    } else {
      this.errorMessage = 'Please fill in all required fields.';
      setTimeout(() => { this.errorMessage = ''; }, 3000);
    }
  }

  deleteApartment(apartment: any) {
    this.successMessage = '';
    this.errorMessage = '';

    const index = this.apartments.findIndex(a => a.apartmentNumber === apartment.apartmentNumber);
    if (index !== -1) {
      this.apartments.splice(index, 1);
      this.filteredApartments = this.filteredApartments.filter(a => a.apartmentNumber !== apartment.apartmentNumber);
      this.successMessage = 'Apartment deleted successfully!';
      setTimeout(() => { this.successMessage = ''; }, 3000);
    } else {
      this.errorMessage = 'Error: Apartment not found.';
      setTimeout(() => { this.errorMessage = ''; }, 3000);
    }
  }

  selectApartmentToUpdate(apartment: any) {
    console.log(this.selectedApartment);
    this.selectedApartment = apartment;
    this.updateForm.patchValue({
      apartmentNumber: apartment.apartmentNumber,
      address: apartment.address,
      buildingNumber: apartment.buildingNumber,
      bedrooms: apartment.bedrooms,
      bathrooms: apartment.bathrooms,
      price: apartment.price,
      squareFootage: apartment.squareFootage,
      amenities: {
        pool: apartment.amenities?.includes('Pool') || false,
        gym: apartment.amenities?.includes('Gym') || false,
        parking: apartment.amenities?.includes('Parking') || false
      }
    });
  }
  
  toggleAmenity(amenity: string): void {
    if (this.amenities.includes(amenity)) {
      this.amenities = this.amenities.filter(a => a !== amenity);
    } else {
      this.amenities.push(amenity);
    }
  }

  clearAmenities() {
    this.apartmentForm.get('amenities')?.reset();
    this.updateForm.get('amenities')?.reset();
  }

  onClearSearch() {
    this.searchQuery = '';
    this.selectedApartment = null;
    this.updateForm.reset();
    // this.clearAmenities();
  }
}
